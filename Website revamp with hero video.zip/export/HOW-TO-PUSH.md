# Pushing the revamp to zaifnatra/website

Three files, one deletion, one asset check. Everything is plain React + Vite — no Tailwind, no new dependencies.

## 1. Copy these in

    src/pages/Landing.jsx     (new)
    src/styles/theme.css      (new — create the styles/ folder)
    src/App.jsx               (replaces the current one)

## 2. Trim what it replaces

The new page covers home / about / projects / contact in one scroll, so these are no longer imported:

    src/pages/Home.jsx
    src/pages/About.jsx
    src/pages/Projects.jsx
    src/pages/Contact.jsx
    src/components/Layout.jsx
    src/components/Navigation.jsx

Delete them once you have confirmed the new page looks right. `src/index.css` can stay (theme.css is imported by Landing.jsx and wins on load order) or be deleted — it is no longer needed.

## 3. Assets

Landing.jsx imports from `../assets/` using your existing filenames, so nothing needs renaming:

    salkantay2.JPG  salkantay.JPG  ultra.JPG  cat.jpg
    logo-shopify.png  logo-meta.png  logo-bombardier.png
    original.png  original2.png  screenShot.png  dashboard.png
    retro1.png  retro.png  S1.jpg  S2.jpg  ev.png  heroes1.jpg  campus.jpg

Note: `Contact.jsx` currently imports `../assets/cv.pdf`, which is not in the repo — that import is gone now, and the "View CV" button points at `#`. Drop your CV in `public/cv.pdf` and change that href to `/cv.pdf`.

## 4. Run it

    npm run dev      # check locally
    npm run deploy   # gh-pages, same as before

## Fonts

Instrument Serif + Inter load from Google Fonts at the top of theme.css. If you would rather self-host, download the two families into `src/assets/fonts/` and swap the @import for @font-face rules.
